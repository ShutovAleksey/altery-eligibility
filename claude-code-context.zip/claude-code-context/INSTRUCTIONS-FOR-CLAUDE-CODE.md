# Instructions for Claude Code — Hand-off from claude.ai web

> **Aleksey:** Paste this into Claude Code in VS Code as your next message. Claude Code will read the context files and fix the active bug autonomously.

---

## Task

Welcome. I've been working with another Claude in claude.ai web on this project. We just shipped commit `48bb016` (onboarding flow at `/setup/`), but production at `https://altery-eligibility.vercel.app/setup` returns 404 on all asset files.

**Your job right now:**

1. **Read these three files in this order:**
   - `CLAUDE.md` — full project context, conventions, architecture
   - `BUGS-AND-FIXES.md` — has the active bug (B-001) with exact fix script
   - `INSTRUCTIONS-FOR-CLAUDE-CODE.md` — this file

2. **Verify current state:**
   ```bash
   git log --oneline -5      # confirm 48bb016 is HEAD
   git status                 # should be clean
   ls setup/                  # confirm /setup/ exists with 22 files + assets/
   ```

3. **Apply the B-001 fix** exactly as scripted in `BUGS-AND-FIXES.md` section "ACTIVE BUG". The fix replaces ~20 relative paths with absolute `/setup/...` paths in `setup/index.html` and one path in `setup/onboarding-shell.jsx`.

4. **Before committing:**
   - Show me the full `git diff --cached --stat`
   - Show me the verification grep output (should be zero relative paths remaining)
   - **Wait for my explicit confirmation** before running `git push`

5. **After my confirmation:**
   - Push to main
   - Wait ~30 seconds for Vercel to redeploy
   - Tell me to verify by opening https://altery-eligibility.vercel.app/setup in browser

## After the fix

When `/setup` works (shows the prep checklist with full Altery styling, no console 404s), the next things on the roadmap (per `CLAUDE.md` Mocked Surfaces section):

1. **Real Stripe in onboarding payment** (issue I-002 in BUGS-AND-FIXES)
2. **Form state persistence** (issue I-003)
3. **KYB submit backend endpoint**
4. **Resend domain verification** (issue I-001)

But don't start any of those yet — just fix B-001 first. The other Claude (claude.ai) will plan the bigger pieces; I'll paste those tasks to you when ready.

## Working style

- I'm a non-developer founder. Explain technical things briefly but assume I understand product/business logic deeply.
- Always show diff before commit.
- Always ask before push (unless I explicitly said "push it").
- Speak Russian or English — I'll set the tone in my reply.
- If something looks suspicious (wrong file count, unexpected diff), stop and ask. Don't fix-and-forget.
- When in doubt about a decision (e.g. "should we also change X?"), ask me — don't expand scope silently.

## What's already set up

- VS Code with Claude Code Local extension ✓
- Local clone of `ShutovAleksey/altery-eligibility` at `~/Desktop/altery-eligibility` ✓
- Vercel auto-deploy on push to `main` ✓
- Stripe (test mode), Resend (sandbox), Stripe keys via env vars ✓
- GitHub OAuth in VS Code for push ✓

Ready to start? Read the three context files first, then walk me through your plan before executing.
