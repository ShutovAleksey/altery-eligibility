# Bugs & Fixes — Altery Eligibility

Active bugs and fix patterns. Read this before debugging anything in `/setup/`.

---

## 🔴 ACTIVE BUG (as of May 17, evening)

### B-001 — `/setup` returns 404 on all JS/CSS/JSX assets

**Symptom (browser console at https://altery-eligibility.vercel.app/setup):**
```
Failed to load resource: 404 — i18n.css
Failed to load resource: 404 — i18n.js
Failed to load resource: 404 — i18n-dict-ob.js
Failed to load resource: 404 — components.jsx
... (all 20+ asset files)
Uncaught Error: Could not load https://altery-eligibility.vercel.app/i18n-react.jsx
```

**Root cause:**
Vercel's `cleanUrls: true` serves `/setup/index.html` at the URL `/setup` (no trailing slash). The browser sees `/setup` and treats it as a file, not a directory. All relative paths in `setup/index.html` (like `src="i18n.js"`) resolve to `/i18n.js` instead of `/setup/i18n.js` → 404 cascade.

**Fix — absolute paths in `setup/index.html` and `setup/onboarding-shell.jsx`:**

The Vercel rewrite `/setup/:token → /setup/index.html?token=:token` also affects asset URLs like `/setup/assets/altery-logo-white.svg` — they would get rewritten to `/setup/index.html?token=assets`. So all asset paths inside `/setup/` must use the absolute `/setup/...` prefix.

Run this exact patch:

```bash
# Step 1 — Replace all relative href/src in setup/index.html
# These are the files to update (no surprises):
sed -i.bak -E '
  s|href="tokens.css|href="/setup/tokens.css|g;
  s|href="onboarding-flow.css|href="/setup/onboarding-flow.css|g;
  s|href="onboarding-payment.css|href="/setup/onboarding-payment.css|g;
  s|href="i18n.css|href="/setup/i18n.css|g;
  s|src="i18n.js"|src="/setup/i18n.js"|g;
  s|src="i18n-dict-ob.js"|src="/setup/i18n-dict-ob.js"|g;
  s|src="i18n-dict-ob-de-ru.js"|src="/setup/i18n-dict-ob-de-ru.js"|g;
  s|src="i18n-dict-ob-nl-tr-it.js"|src="/setup/i18n-dict-ob-nl-tr-it.js"|g;
  s|src="i18n-dict-ob-es-pl-pt-fr.js"|src="/setup/i18n-dict-ob-es-pl-pt-fr.js"|g;
  s|src="icons.jsx"|src="/setup/icons.jsx"|g;
  s|src="flags.jsx"|src="/setup/flags.jsx"|g;
  s|src="components.jsx"|src="/setup/components.jsx"|g;
  s|src="i18n-react.jsx"|src="/setup/i18n-react.jsx"|g;
  s|src="date-picker.jsx"|src="/setup/date-picker.jsx"|g;
  s|src="phone-input.jsx"|src="/setup/phone-input.jsx"|g;
  s|src="onboarding-atoms.jsx"|src="/setup/onboarding-atoms.jsx"|g;
  s|src="onboarding-shell.jsx"|src="/setup/onboarding-shell.jsx"|g;
  s|src="onboarding-screens-1.jsx"|src="/setup/onboarding-screens-1.jsx"|g;
  s|src="onboarding-screens-2.jsx"|src="/setup/onboarding-screens-2.jsx"|g;
  s|src="onboarding-screens-payment.jsx"|src="/setup/onboarding-screens-payment.jsx"|g;
  s|src="onboarding-app.jsx"|src="/setup/onboarding-app.jsx"|g;
' setup/index.html

# Step 2 — Asset path in onboarding-shell.jsx (logo)
sed -i.bak 's|src="assets/altery-logo-white.svg"|src="/setup/assets/altery-logo-white.svg"|g' setup/onboarding-shell.jsx

# Step 3 — Clean up backups
rm setup/index.html.bak setup/onboarding-shell.jsx.bak

# Step 4 — Verify (should show only absolute /setup/ paths now)
grep -E 'href="[^/]|src="[^/h]' setup/index.html
# (expect zero output — meaning no relative paths left)

# Step 5 — Commit + push
git add setup/index.html setup/onboarding-shell.jsx
git diff --cached --stat
git commit -m "fix: absolute /setup/ paths so cleanUrls doesn't break asset loads (B-001)"
git push
```

**After Vercel redeploy (~30 sec), verify:**

Open https://altery-eligibility.vercel.app/setup → should show prep checklist with full styling, no console errors.

---

## ✅ FIXED BUGS

### B-000 — Vercel build fails with "Function Runtimes must have a valid version"

**Date:** May 17, evening
**Commit:** part of `48bb016` and follow-up

`vercel.json` had `"runtime": "nodejs20.x"` in the `functions` block. This is AWS Lambda syntax, not Vercel. Fixed by either:
- Removing the `runtime` field entirely (Vercel auto-detects from package.json) — what we did
- OR using full format: `"runtime": "@vercel/node@5.4.2"`

Don't reintroduce the wrong format.

---

## 🟡 KNOWN ISSUES (not breaking, but tracked)

### I-001 — Resend sandbox can't send to non-owner emails

**Symptom:** Emails to non-Gmail (or any non-account-owner) addresses fail silently or with 422.

**Cause:** Resend's `onboarding@resend.dev` sandbox sender only ships to the email address registered with the Resend account.

**Fix needed:** Verify a domain (e.g. `send.altery.com`) on Resend dashboard, then set `FROM_EMAIL=Altery <hello@send.altery.com>` in Vercel env vars. See `api/send-analysis.js` lines 25–28 for the wired env var.

### I-002 — Onboarding payment is a UI mock

`ScreenActivation` in `setup/onboarding-screens-payment.jsx` uses `setTimeout` to simulate Stripe. Real wiring TODO:
1. Add `<script src="https://js.stripe.com/v3/"></script>` to `setup/index.html`
2. Replace `<Input>` fake card fields with Stripe Payment Element mount
3. Call `/api/create-payment-intent` on screen mount (already exists, handles plan price)
4. `stripe.confirmCardPayment()` on submit
5. Use the real returned payment_intent id in the success state

Reference: how `EcPaymentModal` in `index.html` does it (search `function EcPaymentModal`).

### I-003 — No form state persistence across reload

Every screen has local `useState`. If user reloads mid-onboarding, everything is lost.

**Fix pattern:**
1. Lift state to App level → single `formState` object
2. Persist on every change: `useEffect(() => localStorage.setItem('ob:formState', JSON.stringify(formState)), [formState])`
3. Hydrate on mount: `useState(() => JSON.parse(localStorage.getItem('ob:formState') || '{}'))`
4. Send `formState` on submit to KYB endpoint
5. Clear on submit success

---

## Common patterns

### Adding an i18n key

Every new visible string needs translations in all 10 languages:

```bash
# Anchor: pick a stable existing key as insertion point (e.g. ec.pdf.team.calendly)
# Per-lang dict files:
#   index.html (EN inline at ~3500, then DE, RU, NL, TR, IT, ES, PL, PT, FR)
#   setup/i18n-dict-ob.js (EN)
#   setup/i18n-dict-ob-de-ru.js (DE, RU)
#   setup/i18n-dict-ob-nl-tr-it.js (NL, TR, IT)
#   setup/i18n-dict-ob-es-pl-pt-fr.js (ES, PL, PT, FR)

# Audit count — must be 10 occurrences per key
grep -c '"YOUR_NEW_KEY"' index.html setup/i18n-dict-*.js | grep -v ':0'
```

### Routing in onboarding

`ALL_STEPS` in `setup/onboarding-app.jsx` is the source of truth for step order. `STEP_INDEX` in `setup/onboarding-shell.jsx` is derived but must match. `SECTIONS` defines which steps belong to which top-of-page section pill.

If you add a step, update **three** places.

### Sectioning a step as "all-sections-done" (review/payment/submit)

`sectionState()` in `setup/onboarding-shell.jsx` has a `reviewSteps` array — if the user is on one of these, all 4 section pills show completed. Add new tail-end steps there.
