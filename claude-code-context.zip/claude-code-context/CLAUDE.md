# Altery Eligibility Checker — Project Context

> **For Claude Code:** Read this file first in any new session. It carries the working context that's normally lost between chats. After reading, also do `git log --oneline -20` to see recent changes, then `git status` to see uncommitted work.

---

## Working with this user

The user (Aleksey Shutov, founder/CEO of Altery) primarily works in **claude.ai web** with another Claude instance for strategy, design, and complex code generation. He uses **you (Claude Code in VS Code)** as the execution layer:
- Apply the changes the other Claude planned
- Run git operations (status / diff / add / commit / push)
- Search the repo, find files, run scripts
- Handle anything that needs the local filesystem or terminal

Workflow expectation:
- He gives you a task (often pasted from claude.ai conversation)
- You execute, show diff, ask permission before destructive operations
- He approves → you push to GitHub → Vercel auto-deploys

When in doubt — show him the diff/plan before committing. He values seeing the change before it goes live.

---

## What this project is

A single-page React app deployed at `altery-eligibility.vercel.app`. Pre-onboarding eligibility checker for Altery Business banking — a 5-question quiz that recommends entity (UK / EU / MENA), plan (Starter / Pro / Ultra), and routes to KYB onboarding.

Two surfaces:
1. **The checker** — `/index.html` — anonymous quiz, ends with "Your savings opportunity" pitch + email-capture PDF + "Start setup" CTA
2. **The onboarding** — `/setup/` — 14-step KYB flow (imported from Claude Design, modular React + Babel)

## Architecture

```
altery-eligibility/                  ← GitHub repo, deployed to Vercel
├── index.html                       ← The CHECKER (single ~13k-line file, all React/JSX/CSS inline)
├── setup/                           ← The ONBOARDING (modular bundle)
│   ├── index.html                   ← Entry, loads scripts in dependency order
│   ├── tokens.css, onboarding-flow.css, onboarding-payment.css, i18n.css
│   ├── i18n.js + 4 dict files       ← 10 languages: en/de/ru/nl/tr/it/es/pl/pt/fr
│   ├── components.jsx               ← Shared DS (Button, Input, Tag, Modal, ...)
│   ├── icons.jsx, flags.jsx
│   ├── date-picker.jsx, phone-input.jsx
│   ├── onboarding-atoms.jsx         ← Title, Field, TopRow, WhyWeAsk
│   ├── onboarding-shell.jsx         ← Header with progress, sections
│   ├── onboarding-screens-1.jsx     ← prep → welcome → password → verify → phone → country → business-info → activity
│   ├── onboarding-screens-2.jsx     ← documents → ubo-list → ubo-form → review → submit
│   ├── onboarding-screens-payment.jsx  ← Plans + payment screen (ScreenActivation)
│   ├── onboarding-app.jsx           ← Main App, ALL_STEPS, URL param parsing
│   └── assets/                      ← Logo (white/dark), 245 country flag SVGs
├── api/                             ← Vercel serverless functions
│   ├── config.js                    ← Shared config (Stripe keys env-loaded)
│   ├── create-payment-intent.js     ← Stripe PaymentIntent creation
│   └── send-analysis.js             ← Resend email delivery with PDF attachment
├── images/                          ← Checker brand assets + perk illustrations
├── vercel.json                      ← cleanUrls + rewrite /setup/:token → /setup/index.html?token=:token
├── package.json                     ← Vercel runtime deps (node 20.x default)
├── CLAUDE.md                        ← This file
└── BUGS-AND-FIXES.md                ← Active bug tracker, fix patterns
```

## How the two surfaces connect

1. User lands on `/` → answers 5 questions in checker → sees recommendation + cost-projection hook
2. Optionally emails themselves the PDF proposal (Resend via `/api/send-analysis`)
3. Clicks "Start setup" → checker does `window.location.href = "/setup?token=...&plan=pro&entity=uk&currency=GBP&volume=750000"`
4. Onboarding reads URL params, skips prep checklist, goes straight to welcome
5. User runs 13 KYB screens → hits the payment screen (`ScreenActivation` with `mode="presubmit"`) → authorises activation fee
6. Payment success → `ScreenSubmit` shows "Application in review"

## Tech stack

- **No build step**. React 18 + Babel Standalone (compiled in-browser). Trade-off: simpler ops, slower first load (~1s Babel compile). Don't reach for webpack/vite without strong reason.
- **Vercel** for hosting + serverless functions (10s `maxDuration` on `api/*.js`).
- **Stripe** for payment (test keys in env, live keys come from Vercel env vars).
- **Resend** for transactional email (PDF attachment via base64).
- **html2canvas + jsPDF** UMD (from CDN) for PDF generation — not html2pdf wrapper. See `ecGenerateProposalPDF` in `index.html`. The 0×0 invisible-mounted wrapper trick is used.

## Brand & design tokens

- Primary navy: `#002780` (corporate, headers, primary CTAs)
- Accent: `#006FFF` (links, secondary actions)
- Header dark navy: `#000537` (.ec-header background)
- Beige: `#F0EBE3` (callouts, account-team panel)
- Savings orange: `#C2410C` text on `#FFF7ED` bg (loss-framed "leaving on the table")
- Ink: `#11141A`, Muted: `#69707C`, Border: `#D7DAE0`
- Success: `#0A9F52`, Danger: `#CD1918`, Warning: `#FF771C`
- Fonts: Inter for UI, IBM Plex Mono for numbers/code

## Recent major iterations (newest first)

**Onboarding flow integration (May 17)** — commit `48bb016`
- Copied Claude Design's onboarding bundle into `setup/`
- Added `payment` step between `review` and `submit` in `ALL_STEPS`
- `ScreenActivation` extended with `mode="presubmit"`: authorisation captured on KYB approve, refunded on reject
- Checker's `onContinueToSetup` now redirects to `/setup` with URL params
- Added `ob.step.payment` i18n key for 10 languages
- Vercel rewrite preserves `/setup/{token}` pretty URL from PDF/email
- **ACTIVE BUG**: see BUGS-AND-FIXES.md — 404 on assets when /setup is accessed without trailing slash

**Psychological sales conversion redesign (May 15)**
- "Your savings opportunity" loss-framed hook on result page
- PDF: cost-projection table, outcomes block, comparison table, onboarding checklist, signature, validity
- Handoff modal: value-prop list, "3 things to do next", send-to-colleague viral hook
- Helper `ecComputeCostBreakdown(rec)` — FX 0.65% vs 2.5%, SWIFT €10+0.25% vs €40

**Email delivery via Resend (May 14)**
- `/api/send-analysis` with PDF attached as base64
- **Known issue**: sandbox `onboarding@resend.dev` only sends to account-owner. Domain verification (e.g. `send.altery.com`) needed for prod.

## Mocked surfaces (need real wiring before prod traffic)

1. **Onboarding payment is a UI mock.** `ScreenActivation` uses `setTimeout` to simulate Stripe. Real wiring: import Stripe.js into `setup/index.html`, replace fake card inputs with Stripe Payment Element, call `/api/create-payment-intent` on mount, `stripe.confirmCardPayment()` on submit.
2. **KYB submission backend.** `ScreenSubmit` is a static state. Need `/api/submit-kyb` endpoint that forwards to KYB provider (Sumsub/Veriff/internal).
3. **Onboarding form state persistence.** Each screen has its own `useState`, nothing persists. Need central state + localStorage.
4. **Resend domain verification.** Currently sandbox-only.
5. **Currency mapping for MENA.** Checker passes `currency: rec.entity.id === "uk" ? "GBP" : "EUR"`. MENA entities may want USD.

## Conventions

- **Comments**: explain *why* not *what*. Code shows what; comments explain decisions, constraints, tradeoffs.
- **i18n keys**: dot-separated. EC = eligibility checker, OB = onboarding. Example: `ec.r.opportunity.head`, `ob.step.payment`.
- **i18n languages, file order**: en, de, ru, nl, tr, it, es, pl, pt, fr. Each new key must appear in all 10.
- **CSS naming**: BEM-ish — `.ec-block__element` for checker, `.ob-block__element` for onboarding, `.pp-` for payment.
- **No build dependencies for SPA code**.
- **Stripe test keys** in `.env.local` (gitignored) for dev, Vercel env vars for production.
- **Always test PDF generation** after changes to `ecGenerateProposalPDF`.

## Vercel deploy traps (learnt the hard way)

1. **Don't put `runtime: "nodejs20.x"` in `vercel.json`'s `functions` block.** That's AWS Lambda syntax, not Vercel. Either omit `runtime` entirely (Vercel auto-detects) OR use `"runtime": "@vercel/node@5.4.2"` (note the scope and @version). Wrong runtime field fails the whole build with cryptic error.

2. **`cleanUrls: true` + relative paths = 404 cascade.** When Vercel serves `/setup/index.html` at URL `/setup` (no trailing slash), the browser thinks `setup` is a file, not a directory. All relative paths in HTML (e.g. `src="i18n.js"`) resolve to `/i18n.js` instead of `/setup/i18n.js`. **Fix: always use absolute paths starting with `/setup/` for assets inside setup/.** Same logic applies if we add other subfolder bundles later.

3. **Vercel rewrites apply to ALL matching routes.** If you add `/setup/:token → /setup/index.html?token=:token`, then `/setup/assets/altery-logo-white.svg` also matches and gets rewritten to `/setup/index.html?token=assets`. To avoid: make rewrite source more specific, or accept that assets must use absolute `/setup/assets/...` paths (which they should anyway per point 2).

## Useful commands

```bash
# Local preview
npx vercel dev

# Check JS syntax
node --check api/send-analysis.js

# Find untranslated keys
grep -rn "ec\.\|ob\." index.html setup/*.jsx | grep -v "i18n-dict"

# Audit translation completeness — should be 10 occurrences per key
for k in "ec.r.opportunity.head" "ob.step.payment"; do
  echo "$k: $(grep -c "\"$k\"" index.html setup/i18n-dict-*.js)"
done

# Test full build locally (mimics Vercel)
npx vercel build
```

## Don't do these things

- Don't use `localStorage` inside React artifacts the checker generates — sandbox blocks it. Use React state.
- Don't put `<form>` tags in React Babel-compiled JSX — Babel-inline doesn't handle native form submission. Use `<button onClick>`.
- Don't add a build step (webpack/vite) without a strong reason. Inline-Babel is deliberate.
- Don't invent Altery capabilities (Confirmed / In progress / Provider-dependent / Unknown statuses).
- Don't reproduce 20+ words verbatim from any source — copyright. Paraphrase.
- Don't hardcode "Step N of M" eyebrows — breaks when flows change.
- Don't use relative paths in HTML inside `/setup/` (see Vercel trap #2 above).
- Don't put `runtime: "nodejs20.x"` in `vercel.json` (see Vercel trap #1).
